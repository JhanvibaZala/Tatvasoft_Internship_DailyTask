﻿using Mission.Entities.Models.ViewModels;
using Mission.Entities.Models.ViewModels.Login;
using Mission.Repositories.IRepository;
using Mission.Services.IService;

namespace Mission.Services.Services
{
    public class UserService(IUserRepository userRepository) : IUserService

    {
        private readonly IUserRepository _userRepository = userRepository;
        private readonly JwtService _jwtService;


        // added from chatgpt

        //public UserService(IUserRepository userRepository, JwtService jwtService)
        //{
        //    _userRepository = userRepository;
        //    _jwtService = jwtService;
        //}

        //till here

        public async Task<ResponseResult> LoginUser(UserLoginRequestModel model)
        {
            var (response,message) = await _userRepository.LoginUser(model);
            var result = new ResponseResult()
            {
                Message = message
            };

            if (response == null)
            {
                result.Result = ResponseStatus.Error;
            }

            else
            {
                result.Data = _jwtService.GenerateJwtToken(response);
                result.Result = ResponseStatus.Success; 
            };
            return result;
        }
    }
}
