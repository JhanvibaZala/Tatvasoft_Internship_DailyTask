﻿namespace Missin.Entities
{
    public class Class1
    {

    }
}
