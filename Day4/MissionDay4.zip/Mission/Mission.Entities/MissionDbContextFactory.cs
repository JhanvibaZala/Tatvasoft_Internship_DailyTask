﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace Mission.Entities
{
    public class MissionDbContextFactory : IDesignTimeDbContextFactory<MissionDbContext>
    {
        public MissionDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<MissionDbContext>();

            // ✅ Direct PostgreSQL connection string
            optionsBuilder.UseNpgsql("Host=localhost;Port=5432;Database=MissionDB2025;Username=postgres;Password=Jhanviba@29");

            return new MissionDbContext(optionsBuilder.Options);
        }
    }
}
