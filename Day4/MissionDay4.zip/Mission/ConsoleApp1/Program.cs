﻿using Mission.Entities;
using Mission.Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;

var config = new ConfigurationBuilder()
    .SetBasePath(Directory.GetCurrentDirectory())
    .AddJsonFile("appsettings.json")
    .Build();

var services = new ServiceCollection();

services.AddDbContext<MissionDbContext>(options =>
    options.UseNpgsql(config.GetConnectionString("DefaultConnection")));

var provider = services.BuildServiceProvider();

using var context = provider.GetRequiredService<MissionDbContext>();

var newUser = new User
{
    FirstName = "Jane",
    LastName = "Doe",
    EmailAddress = "jane.doe@new.com",
    Password = "Test@123", // In real apps, hash it!
    PhoneNumber = "9876543210",
    UserType = "admin"
};

context.Users.Add(newUser);
context.SaveChanges();

Console.WriteLine("✅ New user added to PostgreSQL!");
