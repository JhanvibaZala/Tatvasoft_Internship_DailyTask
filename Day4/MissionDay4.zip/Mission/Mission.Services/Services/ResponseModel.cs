﻿using Mission.Entities.Models.ViewModels;

namespace Mission.Services.Services
{
    internal class ResponseModel<T> : ResponseResult
    {
        public object Data { get; set; }
        public string Message { get; set; }
        public ResponseStatus Result { get; set; }
    }
}