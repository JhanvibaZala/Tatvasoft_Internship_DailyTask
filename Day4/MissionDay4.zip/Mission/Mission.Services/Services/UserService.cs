﻿using Mission.Entities.Models.ViewModels;
using Mission.Entities.Models.ViewModels.Login;
using Mission.Repositories.IRepository;
using Mission.Services.IService;

namespace Mission.Services.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly JwtService _jwtService;

        public UserService(IUserRepository userRepository, JwtService jwtService)
        {
            _userRepository = userRepository;
            _jwtService = jwtService;
        }

        public async Task<ResponseResult> LoginUser(UserLoginRequestModel model)
        {
            var (user, message) = await _userRepository.LoginUser(model);
            var result = new ResponseResult();

            if (user == null)
            {
                result.Result = ResponseStatus.Error; // ✅ Mark as error
                result.Message = message ?? "Invalid email or password.";
                result.Data = null;
            }
            else
            {
                var token = _jwtService.GenerateJwtToken(user);
                result.Data = token;
                result.Result = ResponseStatus.Success; // ✅ Mark as success
                result.Message = "Login successful";
            }
            return result;
        }
    }
}
