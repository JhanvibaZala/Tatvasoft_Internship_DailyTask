﻿using Mission.Entities.Models.ViewModels;
using Mission.Entities.Models.ViewModels.Login;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mission.Services.IService
{
    public interface IUserService
    {
        Task<ResponseResult> LoginUser(UserLoginRequestModel model);
    }
}
